// home.js - main app logic (modular firebase)
import { app, auth, db, storage } from './firebase.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {
  collection, doc, getDoc, setDoc, addDoc, onSnapshot, query, where, orderBy, updateDoc, arrayUnion, arrayRemove, serverTimestamp, getDocs, limit
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js";

let currentUser = null;

// UI refs
const productGrid = document.getElementById('productGrid');
const wishlistContainer = document.getElementById('wishlistContainer');
const badgesContainer = document.getElementById('badgesContainer');
const meLevel = document.getElementById('meLevel');
const meCoins = document.getElementById('meCoins');

// Auth state
onAuthStateChanged(auth, async user => {
  if (!user) {
    window.location.href = 'index.html';
    return;
  }
  currentUser = user;
  await ensureUserDoc(user);
  subscribeProducts();
  loadUserUI();
});

async function ensureUserDoc(user) {
  const uref = doc(db, 'users', user.uid);
  const snap = await getDoc(uref);
  if (!snap.exists()) {
    await setDoc(uref, {
      email: user.email||null,
      role: 'buyer',
      name: user.displayName||null,
      coins: 0,
      points: 0,
      level: 'Rosebud',
      badges: [],
      wishlist: [],
      following: [],
      createdAt: serverTimestamp()
    });
  }
}

// Subscribe products collection
function subscribeProducts() {
  const q = query(collection(db, 'products'), orderBy('createdAt', 'desc'));
  onSnapshot(q, snap=>{
    productGrid.innerHTML = '';
    snap.forEach(docSnap=>{
      const p = docSnap.data(); p.id = docSnap.id;
      renderProductCard(p);
    });
  });
}

// Render product card
function renderProductCard(p) {
  const div = document.createElement('div'); div.className='card';
  const img = document.createElement('img'); img.src = p.images?.[0]||'placeholder.png';
  const title = document.createElement('div'); title.className='title'; title.textContent = p.title;
  const price = document.createElement('div'); price.className='price'; price.textContent = `$${p.price}`;
  const meta = document.createElement('div'); meta.className='meta';
  const btnWishlist = document.createElement('button'); btnWishlist.textContent='♡'; btnWishlist.onclick=()=>toggleWishlist(p.id);
  const btnView = document.createElement('button'); btnView.textContent='View'; btnView.onclick=()=>openProduct(p.id);
  meta.appendChild(btnWishlist); meta.appendChild(btnView);
  div.appendChild(img); div.appendChild(title); div.appendChild(price); div.appendChild(meta);
  productGrid.appendChild(div);
}

// Toggle wishlist
async function toggleWishlist(productId) {
  const uref = doc(db, 'users', currentUser.uid);
  const snap = await getDoc(uref);
  const wish = snap.data().wishlist || [];
  if (wish.includes(productId)) {
    await updateDoc(uref, { wishlist: arrayRemove(productId) });
  } else {
    await updateDoc(uref, { wishlist: arrayUnion(productId) });
  }
  loadWishlistUI();
}

// Load wishlist and UI
async function loadWishlistUI() {
  const uref = doc(db, 'users', currentUser.uid);
  const snap = await getDoc(uref);
  const wish = snap.data().wishlist || [];
  wishlistContainer.innerHTML = '';
  for (const pid of wish) {
    const pDoc = await getDoc(doc(db, 'products', pid));
    if (!pDoc.exists()) continue;
    const p = pDoc.data(); p.id = pDoc.id;
    const el = document.createElement('div'); el.textContent = p.title + ' — $' + p.price;
    wishlistContainer.appendChild(el);
  }
}

// Open product modal (simple view + buy)
async function openProduct(productId) {
  const pDoc = await getDoc(doc(db,'products',productId));
  if (!pDoc.exists()) return alert('Product not found');
  const p = pDoc.data();
  const modal = document.createElement('div'); modal.className='modal';
  modal.innerHTML = `<div class="content"><h3>${p.title}</h3><img src="${p.images?.[0]||''}" style="max-width:100%;height:220px;object-fit:cover"/><p>${p.description||''}</p><p>Price: $${p.price}</p><div><button id="buyBtn">Buy</button> <button id="closeModal">Close</button></div></div>`;
  document.body.appendChild(modal);
  modal.querySelector('#closeModal').onclick = ()=>modal.remove();
  modal.querySelector('#buyBtn').onclick = async ()=>{
    await buyProduct(productId, p.price, p.sellerId);
    modal.remove();
  };
}

// Buy product (creates order, awards coins/points)
async function buyProduct(productId, price, sellerId) {
  // create order doc
  await addDoc(collection(db,'orders'),{
    buyerId: currentUser.uid, sellerId, products:[{productId,price,quantity:1}], total:price, status:'completed', createdAt:serverTimestamp()
  });
  // award coins equal to floor(price)
  const uref = doc(db,'users',currentUser.uid);
  const snap = await getDoc(uref);
  const coins = (snap.data().coins||0) + Math.floor(price);
  await updateDoc(uref,{coins});
  loadUserUI();
  alert('Purchase complete! Coins awarded.');
}

// Load user UI values
async function loadUserUI() {
  const uref = doc(db,'users',currentUser.uid);
  const snap = await getDoc(uref);
  const data = snap.data();
  meLevel.textContent = data.level||'Rosebud';
  meCoins.textContent = data.coins||0;
  badgesContainer.innerHTML = '';
  (data.badges||[]).forEach(b=>{
    const el=document.createElement('span'); el.className='badge'; el.textContent=b; badgesContainer.appendChild(el);
  });
  loadWishlistUI();
}

// Open product details from card
function openProductById(id){ openProduct(id); }

// Flora AI placeholder (uploads image and returns mocked suggestions)
document.getElementById('floraAsk').addEventListener('click', async ()=>{
  const text = document.getElementById('floraInput').value;
  const file = document.getElementById('floraImage').files[0];
  let imageUrl = null;
  if (file) {
    const sref = ref(storage, `flora/${currentUser.uid}/${Date.now()}_${file.name}`);
    await uploadBytes(sref, file);
    imageUrl = await getDownloadURL(sref);
  }
  const results = [{title:'Floral Dress',price:49,imageUrl:'https://via.placeholder.com/120'},{title:'Green Shawl',price:19,imageUrl:'https://via.placeholder.com/120'}];
  const box = document.getElementById('floraResponses'); box.innerHTML='';
  results.forEach(r=>{ const c=document.createElement('div'); c.className='card'; c.innerHTML=`<img src="${r.imageUrl}"><div class="title">${r.title}</div><div class="price">$${r.price}</div>`; box.appendChild(c); });
});

// image search upload
document.getElementById('searchBtn').addEventListener('click', async ()=>{
  const file = document.getElementById('imgSearchFile').files[0];
  const q = document.getElementById('searchInput').value.trim();
  if (file) {
    const sref = ref(storage, `search/${currentUser.uid}/${Date.now()}_${file.name}`);
    await uploadBytes(sref, file);
    const imageUrl = await getDownloadURL(sref);
    alert('Image uploaded — AI search placeholder (no external AI configured).');
  } else if (q) {
    alert('Text search placeholder — filtered client-side in next iteration.');
  } else {
    alert('Enter search or upload a photo.');
  }
});